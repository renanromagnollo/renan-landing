'use client'

import useEmblaCarousel from "embla-carousel-react";
import AutoScroll from "embla-carousel-auto-scroll";
import { BlogCard } from "./card";
import { TBlogFeaturePost } from "@/src/domain";

export function BlogCarroussel({ blogs, locale }: { blogs: TBlogFeaturePost[] } & { locale: 'pt' | 'en' }) {

  console.log(blogs.length)

  const [emblaRef] = useEmblaCarousel({
    loop: true,
    align: "start",
    dragFree: true,
  },
    [
      AutoScroll({
        speed: 0.5,
        startDelay: 1500,
        stopOnInteraction: false,
        stopOnMouseEnter: true,
      }),
    ]
  )

  return (
    <section className="relative w-full pb-30  bg-background">

      <div ref={emblaRef} className="">
        <div className="
          flex 
          gap-6
          px-6
          md:px-20
        ">
          {blogs?.map(blog => (
            <div
              key={blog.slug}
              className="
                flex-[0_0_85%]
                sm:flex-[0_0_60%]
                md:flex-[0_0_40%]
                lg:flex-[0_0_30%]
              "
            >
              <BlogCard locale={locale} key={blog.slug} blog={blog} />
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}