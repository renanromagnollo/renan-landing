import { TBlogFeaturePost } from "@/src/domain";
import clsx from "clsx";
import Image from "next/image";
import Link from "next/link";

export function BlogCard({ blog, className, locale }: { blog: TBlogFeaturePost, className?: string, locale?: 'pt' | 'en' }) {
  return (
    <Link href={`/${locale}/blog/${blog.slug}`}>
      <div className={clsx("relative min-w-[400px] h-[550px] shrink-0 shadow-2xl", className)}>
        <div className="absolute z-10 bottom-0 left-0 px-10 w-full h-[30%] bg-black opacity-50">

          <h5 className="pt-5 relative text-light-default">{blog.title}</h5>
        </div>
        <Image
          className=" object-cover object-center"
          src={blog?.image || "https://picsum.photos/seed/picsum/200/300"}
          alt="Blog image"
          // width={300} 
          // height={600} />
          fill
          priority
        />
      </div>
    </Link>
  )
}